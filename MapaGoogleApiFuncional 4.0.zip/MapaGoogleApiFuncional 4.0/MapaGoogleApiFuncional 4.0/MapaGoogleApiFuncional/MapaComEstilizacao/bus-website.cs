bus-website/
│
├── app.py
├── routes/
│   └── api.py
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   ├── script.js
│   └── images/
│       └── bus_icon.jpg  # Exemplo de ícone de ônibus
└── database/
    └── models.py

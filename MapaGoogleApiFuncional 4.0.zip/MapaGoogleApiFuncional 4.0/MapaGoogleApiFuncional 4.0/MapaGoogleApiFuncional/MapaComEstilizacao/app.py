from flask import Flask, render_template, jsonify, redirect, url_for, request
import math
import os
import json

app = Flask(__name__)

localizacao_motorista = {"lat": 0, "lng": 0}

@app.route('/atualizar_motorista', methods=['POST'])
def atualizar_motorista():
    global localizacao_motorista
    data = request.get_json()
    localizacao_motorista = data
    return jsonify({"status": "Localização atualizada"})

@app.route('/localizacao_motorista', methods=['GET'])
def obter_localizacao_motorista():
    return jsonify(localizacao_motorista)
# Caminho do arquivo TXT e JSON
txt_file = "rotas.txt"
json_file = "rotas.json"

# Exemplo de dados estáticos para cidades e rotas
cidades = {
    "Cidade1": [
        {"rota": "Centro - Bairro A", "horarios": ["08:00", "12:00", "18:00"]},
        {"rota": "Centro - Bairro B", "horarios": ["09:00", "13:00", "19:00"]}
    ],
    "Cidade2": [
        {"rota": "Centro - Bairro C", "horarios": ["10:00", "14:00", "20:00"]}
    ]
}

# Processa o arquivo TXT
rotas = []
if os.path.exists(txt_file):
    with open(txt_file, "r") as file:
        for linha in file:
            if linha.startswith('Título'):  # Ignorar linhas que começam com 'Título'
                continue  # Passa para a próxima linha

            partes = linha.split(": ")
            if len(partes) < 2:
                continue  # Se a linha não está no formato esperado, ignora

            try:
                dados = partes[1].strip().replace("Origin", '"origin"').replace("Destination", '"destination"').replace("Bus", '"busLocation"').replace("{", '{"').replace(", ", '", "').replace(": ", '": ')

                # Se necessário, acrescente um ID para cada rota
                id_rota = len(rotas) + 1
                rota = json.loads(f'{{"id": {id_rota}, {dados}}}')
                rotas.append(rota)
            except Exception as e:
                print(f"Erro ao processar linha: {linha.strip()} - Erro: {str(e)}")
                continue  # Ignora qualquer erro e passa para a próxima linha

# Salva as rotas no arquivo JSON
with open(json_file, "w") as file:
    json.dump(rotas, file, indent=4)

print(f"Arquivo JSON salvo como {json_file}")

# Função para calcular a distância usando Haversine
def haversine(coord1, coord2):
    R = 6371.0  # Raio da Terra em km
    lat1, lon1 = math.radians(coord1[0]), math.radians(coord1[1])
    lat2, lon2 = math.radians(coord2[0]), math.radians(coord2[1])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    distancia = R * c
    return distancia

# Rota para salvar a rota no arquivo .txt e .json
@app.route('/salvar-rota', methods=['POST'])
def salvar_rota():
    data = request.get_json()
    
    # Depuração: Exibe os dados recebidos
    print(f"Dados recebidos: {data}")

    # Verifica se 'rotas' está presente no JSON
    if 'rotas' not in data:
        return jsonify({'error': 'Campo "rotas" não encontrado'}), 400
    
    rotas = data['rotas']

    # Verifica se existe pelo menos uma rota
    if not rotas:
        return jsonify({'error': 'Nenhuma rota fornecida'}), 400
    
    # Processa as rotas
    for ponto in rotas:
        # Depuração: Exibe cada ponto de rota
        print(f"Processando ponto de rota: {ponto}")

        # Verifica se todas as chaves obrigatórias estão presentes
        if not all(key in ponto for key in ['origin', 'destination', 'busLocation', 'time']):
            missing_keys = [key for key in ['origin', 'destination', 'busLocation', 'time'] if key not in ponto]
            return jsonify({'error': f'Faltando dados obrigatórios: {", ".join(missing_keys)}'}), 400
        
        # Salvar no arquivo .txt
        with open(txt_file, 'a') as file:
            file.write(f"Título: {ponto.get('title', 'Sem Título')}, Horário: {ponto.get('time')}, "
                       f"Lat: {ponto['location']['lat']}, Lng: {ponto['location']['lng']}\n")
        file.write('\n')  # Separador entre rotas
        
    # Salvar no arquivo .json
    try:
        with open(json_file, 'r') as file:
            rotas_json = json.load(file)
    except FileNotFoundError:
        rotas_json = []

    for ponto in rotas:
        nova_rota = {
            "id": len(rotas_json) + 1,  # ID sequencial para a rota
            "origin": ponto.get('origin'),
            "destination": ponto.get('destination'),
            "busLocation": ponto.get('busLocation'),
            "time": ponto.get('time')
        }
        rotas_json.append(nova_rota)

    with open(json_file, 'w') as file:
        json.dump(rotas_json, file, indent=4)

    return jsonify({'message': 'Rota salva com sucesso!'})



@app.route('/')
def login():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def processar_login():
    usuario_tipo = request.form.get('usuario_tipo')
    if usuario_tipo == 'motorista':
        return redirect(url_for('cadastro_motorista'))
    else:
        return redirect(url_for('index'))

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/cadastro_motorista')
def cadastro_motorista():
    return render_template('cadastro_motorista.html')

@app.route('/cadastrar_motorista', methods=['POST'])
def cadastrar_motorista():
    nome = request.form.get('nome')
    email = request.form.get('email')
    senha = request.form.get('senha')
    return redirect(url_for('criar_rota'))

@app.route('/criar_rota')
def criar_rota():
    return render_template('criar_rota.html')

@app.route('/rotas/<cidade>', methods=['GET'])
def obter_rotas(cidade):
    rotas = cidades.get(cidade, [])
    return jsonify(rotas)

@app.route('/distancia', methods=['POST'])
def calcular_distancia():
    data = request.json
    ponto_usuario = data['ponto_usuario']
    ponto_onibus = data['ponto_onibus']
    distancia = haversine(ponto_usuario, ponto_onibus)
    return jsonify({"distancia": distancia})

@app.route('/tela_passageiro')
def tela_passageiro():
    return "Bem-vindo à tela do Passageiro!"

@app.route('/login_motorista')
def login_motorista():
    return render_template('login_motorista.html')

@app.route('/obter-rotas', methods=['GET'])
def obter_rotas_json():
    try:
        with open(json_file, 'r') as file:
            rotas = json.load(file)
        return jsonify(rotas)
    except FileNotFoundError:
        return jsonify({"error": "Nenhuma rota encontrada."}), 404
    except Exception as e:
        return jsonify({"error": f"Erro ao obter as rotas: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True)

let map;
let markers = [];
let routeCoordinates = [];
let polyline;
let lastClickMarker;
let directionsService;
let directionsRenderer;

function enviarLocalizacaoMotorista() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((pos) => {
            const coordenadas = {
                lat: pos.coords.latitude,
                lng: pos.coords.longitude
            };
            
            fetch('/atualizar_motorista', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(coordenadas)
            });
        });
    } else {
        console.log("Geolocalização não suportada.");
    }
}

// Envia a localização a cada 5 segundos
setInterval(enviarLocalizacaoMotorista, 5000);


function initMap() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            const userLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            map = new google.maps.Map(document.getElementById('map'), {
                center: userLocation,
                zoom: 12
            });

            new google.maps.Marker({
                position: userLocation,
                map: map,
                title: "Sua Localização",
                icon: {
                    url: "../static/images/front-of-bus.png", 
                    scaledSize: new google.maps.Size(30, 30) 
                }  
            });

            // Inicializa o serviço de direções e o renderizador
            directionsService = new google.maps.DirectionsService();
            directionsRenderer = new google.maps.DirectionsRenderer({
                map: map,
                suppressMarkers: true // Para não exibir marcadores padrão
            });
        }, function() {
            handleLocationError(true);
        });
    } else {
        handleLocationError(false);
    }

    map.addListener('click', function(event) {
        if (lastClickMarker) {
            lastClickMarker.setMap(null);
        }
        lastClickMarker = new google.maps.Marker({
            position: event.latLng,
            map: map,
            title: "Último Clique",
            icon: {
                url: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png"
            }
        });

        const title = document.getElementById('stop-title').value;
        const time = document.getElementById('stop-time').value;

        if (title && time) {
            addMarker(event.latLng, title);
            addStopToList(title, time);
        } else {
            alert('Por favor, preencha um título e um horário para a parada.');
        }
    });
}

function handleLocationError(browserHasGeolocation) {
    const defaultLocation = { lat: -23.550520, lng: -46.633308 };
    map = new google.maps.Map(document.getElementById('map'), {
        center: defaultLocation,
        zoom: 12
    });
    alert(browserHasGeolocation
        ? "Erro: O serviço de geolocalização falhou."
        : "Erro: Seu navegador não suporta geolocalização.");
}

function addMarker(location, title) {
    const marker = new google.maps.Marker({
        position: location,
        map: map,
        title: title
    });
    markers.push(marker);
    routeCoordinates.push(location);
}

function addStart() {
    const startTitle = document.getElementById('start-title').value;
    const startTime = document.getElementById('start-time').value;

    if (startTitle && startTime) {
        addMarker(map.getCenter(), startTitle);
        alert(`Ponto de início adicionado: ${startTitle} - Horário: ${startTime}`);
    } else {
        alert('Por favor, preencha um título e um horário para o ponto de início.');
    }
}

function clearStart() {
    document.getElementById('start-title').value = '';
    document.getElementById('start-time').value = '';
}

function addStop() {
    const title = document.getElementById('stop-title').value;
    const time = document.getElementById('stop-time').value;

    if (title && time) {
        addMarker(map.getCenter(), title);
        addStopToList(title, time);
    } else {
        alert('Por favor, preencha um título e um horário para a parada.');
    }
}

function clearStop() {
    document.getElementById('stop-title').value = '';
    document.getElementById('stop-time').value = '';
}

function addEnd() {
    const endTitle = document.getElementById('end-title').value;
    const endTime = document.getElementById('end-time').value;

    if (endTitle && endTime) {
        addMarker(map.getCenter(), endTitle);
        alert(`Ponto final adicionado: ${endTitle} - Horário: ${endTime}`);
    } else {
        alert('Por favor, preencha um título e um horário para o ponto final.');
    }
}

function clearEnd() {
    document.getElementById('end-title').value = '';
    document.getElementById('end-time').value = '';
}

function addStopToList(title, time) {
    const stopsList = document.getElementById('stops-list');
    const newListItem = document.createElement('li');
    newListItem.textContent = `Parada: ${title} - Horário: ${time}`;
    stopsList.appendChild(newListItem);
    document.getElementById('stop-title').value = '';
    document.getElementById('stop-time').value = '';
}

function finalizeRoute() {
    if (markers.length > 0) {
        // Cria um array de pontos com o início, as paradas e o fim
        const waypoints = [];
        for (let i = 1; i < markers.length - 1; i++) {
            waypoints.push({
                location: markers[i].getPosition(),
                stopover: true
            });
        }

        const request = {
            origin: markers[0].getPosition(), // Ponto de início
            destination: markers[markers.length - 1].getPosition(), // Ponto final
            waypoints: waypoints,
            travelMode: google.maps.TravelMode.DRIVING // Modo de transporte
        };

        directionsService.route(request, (response, status) => {
            if (status === google.maps.DirectionsStatus.OK) {
                directionsRenderer.setDirections(response);
            } else {
                alert('Não foi possível calcular a rota: ' + status);
            }
        });
    } else {
        alert('Adicione pelo menos um ponto para finalizar a rota.');
    }
}

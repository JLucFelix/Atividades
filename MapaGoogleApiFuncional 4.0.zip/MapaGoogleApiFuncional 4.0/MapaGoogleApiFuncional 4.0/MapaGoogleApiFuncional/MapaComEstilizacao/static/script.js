let map, directionsService, directionsRenderer;
let userMarker, busMarker1, busMarker2;

function initMap() {
    map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: -22.2336, lng: -49.9342 },
        zoom: 13
    });

    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer();
    directionsRenderer.setMap(map);

    // Solicitar a localização do usuário
    atualizarLocalizacao();
}

function atualizarLocalizacao() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            function (position) {
                const usuarioCoords = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                atualizarMarcador(usuarioCoords); // Atualiza o marcador do usuário
                obterRotas(usuarioCoords); // Chama obterRotas com a nova localização do usuário
            },
            function (error) {
                console.error("Erro ao obter a localização: ", error);
                alert("Não foi possível obter sua localização. Verifique suas configurações de geolocalização.");
            }
        );
    } else {
        console.error("Geolocalização não é suportada por este navegador.");
        alert("Geolocalização não é suportada por este navegador.");
    }
}
let motoristaMarker; // Variável global para o marcador do motorista

function obterLocalizacaoMotorista() {
    fetch('/localizacao_motorista')
        .then(response => response.json())
        .then(data => {
            console.log("Localização do motorista:", data);
            atualizarMarcadorMotorista(data); // Atualiza o marcador do motorista no mapa
        })
        .catch(error => console.error("Erro ao obter a localização do motorista:", error));
}

function atualizarMarcadorMotorista(motoristaCoords) {
    const busImage = '/static/images/front-of-bus.png'; // Verifique se o caminho está correto

    // Remove o marcador anterior, se existir
    if (motoristaMarker) motoristaMarker.setMap(null);

    // Cria um novo marcador com a posição atualizada
    motoristaMarker = new google.maps.Marker({
        position: motoristaCoords,
        map: map,
        icon: {
            url: busImage,
            scaledSize: new google.maps.Size(35, 35) // Ajusta o tamanho do ícone
        }
    });
}

// Solicita a localização do motorista a cada 5 segundos
setInterval(obterLocalizacaoMotorista, 5000);

function atualizarMarcadorMotorista(motoristaCoords) {
    const busImage = '../static/images/front-of-bus.png'; // Ícone do motorista (ônibus)

    // Remove o marcador anterior, se existir
    if (motoristaMarker) motoristaMarker.setMap(null);

    // Cria um novo marcador com a posição atualizada
    motoristaMarker = new google.maps.Marker({
        position: motoristaCoords,
        map: map,
        icon: {
            url: busImage,
            scaledSize: new google.maps.Size(35, 35) // Ajusta o tamanho do ícone
        }
    });
}
// Solicita a localização do motorista a cada 5 segundos
setInterval(obterLocalizacaoMotorista, 5000);


function obterRotas(usuarioCoords) {
    const rotaSelecionada = document.getElementById("rota").value;

    const rotas = {
        1: {
            origin: { lat: -22.230550821740806, lng: -49.92295144862242 },
            destination: { lat: -22.186811281400203, lng: -49.967913459074346 },
        },
        2: {
            origin: { lat: -22.230583313093035, lgn:-49.92294840416701 },
            destination: { lat:-22.236529538595274,lgn: -49.96819651410735 },
        },
        3: {
            origin: { lat: -22.239392, lng: -49.922786 },
            destination: { lat: -22.222413, lng: -49.919777 },
        }
    };

    atualizarMarcador(usuarioCoords);
    const rota = rotas[rotaSelecionada];
    calcularRota(rota.origin, rota.destination);
    atualizarMarcadorOnibus(rota.busLocation, rotaSelecionada);
    calcularDistanciaETempo(rota.busLocation, usuarioCoords);
}

function calcularRota(origin, destination) {
    const request = {
        origin: origin,
        destination: destination,
        travelMode: 'DRIVING'
    };

    directionsService.route(request, (result, status) => {
        if (status === 'OK') {
            directionsRenderer.setDirections(result);
            const distanciaKm = (result.routes[0].legs[0].distance.value / 1000).toFixed(2);
            document.getElementById('distancia-trajeto').innerText = `Distância da rota: ${distanciaKm} km`;
        } else {
            console.error('Erro ao obter a rota:', status);
            alert("Não foi possível calcular a rota. Tente novamente.");
        }
    });
}

function atualizarMarcador(usuarioCoords) {
    const userImage = '../static/images/user.png'; // Ícone do usuário

    if (userMarker) userMarker.setMap(null);

    userMarker = new google.maps.Marker({
        position: usuarioCoords,
        map: map,
        icon: {
            url: userImage,
            scaledSize: new google.maps.Size(35, 35)
        }
    });
}

function atualizarMarcadorOnibus(busCoords, rotaSelecionada) {
    const busImage = '../static/images/front-of-bus.png';

    if (busMarker1) busMarker1.setMap(null);
    if (busMarker2) busMarker2.setMap(null);

    const busMarker = new google.maps.Marker({
        position: busCoords,
        map: map,
        icon: {
            url: busImage,
            scaledSize: new google.maps.Size(35, 35)
        }
    });

    if (rotaSelecionada == 1) {
        busMarker1 = busMarker;
    } else if (rotaSelecionada == 2) {
        busMarker2 = busMarker;
    }
}

function calcularDistanciaETempo(busCoords, usuarioCoords) {
    const distanceService = new google.maps.DistanceMatrixService();

    const request = {
        origins: [busCoords],
        destinations: [usuarioCoords],
        travelMode: 'DRIVING',
        drivingOptions: {
            departureTime: new Date(Date.now())
        }
    };

    distanceService.getDistanceMatrix(request, (response, status) => {
        if (status === 'OK') {
            const distanciaKm = (response.rows[0].elements[0].distance.value / 1000).toFixed(2);
            const tempoSegundos = response.rows[0].elements[0].duration.value;
            const tempoMinutos = Math.floor(tempoSegundos / 60);
            const segundosRestantes = Math.round(tempoSegundos % 60);
            
            document.getElementById('distancia-onibus-usuario').innerText = `Distância até o usuário: ${distanciaKm} km`;
            document.getElementById('tempo-onibus-usuario').innerText = `Tempo estimado: ${tempoMinutos} minutos e ${segundosRestantes} segundos`;
        } else {
            console.error('Erro ao calcular a distância e tempo:', status);
            alert("Não foi possível calcular a distância e o tempo. Tente novamente.");
        }
    });
}

function exibirSaudacao() {
    const agora = new Date();
    const hora = agora.getHours();
    let saudacao;

    if (hora < 12) {
        saudacao = "Bom dia!";
    } else if (hora < 18) {
        saudacao = "Boa tarde!";
    } else {
        saudacao = "Boa noite!";
    }

    const saudacaoElement = document.getElementById('saudacao');
    saudacaoElement.innerText = saudacao;
}

// Função para atualizar a localização ao clicar no botão
function atualizarLocalizacaoAoClicar() {
    atualizarLocalizacao();
}

window.onload = function () {
    initMap();
    exibirSaudacao();

    // Adiciona um listener ao botão de atualização
    document.getElementById('atualizar-localizacao').addEventListener('click', atualizarLocalizacaoAoClicar);
};


function selecionarTipo(tipo) {
    const motoristaBtn = document.getElementById('motorista');
    const passageiroBtn = document.getElementById('passageiro');
    const continuarBtn = document.getElementById('continuar');
    const usuarioTipoInput = document.getElementById('usuario_tipo');

    // Remover a classe "selecionado" de ambos os botões
    motoristaBtn.classList.remove('selecionado');
    passageiroBtn.classList.remove('selecionado');

    // Adicionar a classe "selecionado" ao botão clicado
    if (tipo === 'motorista') {
        motoristaBtn.classList.add('selecionado');
        usuarioTipoInput.value = 'motorista'; // Atualiza o valor do campo oculto
    } else {
        passageiroBtn.classList.add('selecionado');
        usuarioTipoInput.value = 'passageiro'; // Atualiza o valor do campo oculto
    }

    // Habilitar o botão continuar
    continuarBtn.disabled = false;
}


// Seleciona o input de senha e o ícone
const passwordInput = document.getElementById('senha');
const togglePassword = document.getElementById('togglePassword');

// Adiciona um evento de clique ao ícone do olho
togglePassword.addEventListener('click', function() {
    // Alterna o tipo do input entre 'password' e 'text'
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);

    // Altera o ícone (opcional)
    if (type === 'text') {
        togglePassword.src = 'path/to/eye-open-icon.jpg'; // Caminho do ícone de olho aberto
    } else {
        togglePassword.src = 'path/to/eye-closed-icon.jpg'; // Caminho do ícone de olho fechado
    }
});



from app import db

# Modelos já inseridos no app.py

# Criando o banco de dados
db.create_all()

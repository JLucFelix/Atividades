<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Firm;

class Product extends Model
{
    protected $table = 'products';
    protected $fillable = ['name', 'price', 'description','category_id', 'id_firm'];
    //
    public function category(){
        return $this->belongsTo(
        Category ::class, 
        'category_id' , 
        'id' 
        );
    }
    public function product()
    {
    return $this->belongsTo(
    Firm::class, 
    'id_firm', 
    'id' 
    );
    }
}
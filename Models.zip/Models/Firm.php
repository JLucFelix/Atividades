<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Product;

class Firm extends Model
{
    protected $table = 'firms';
    protected $fillable = ['corporate_name', 'trade_name ', 'CNPJ'];
    //

    public function category(){

    return $this->hasMany(
        Product::class, //Modelo Relacionado
        'id', // Chave estrangeira de Post na tabela de Comment
        'id_firm' // Cha
    );
    }
}
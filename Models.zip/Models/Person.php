<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Birth_certificate;

class Person extends Model
{
    protected $primaryKey = 'cpf';

    protected $table = 'persons';
    protected $fillable = ['cpf', 'name', 'RG','date_of_birth'];
    //
    public function Birth_certificate(){
        return $this->hasOne(
            Birth_certificate::class, 
            'cpf',
            'cpf' 
    );
    }
    public function creditcards()
    {
    
        return $this->belongsTo(
            CreditCard::class, 
            'cpf', 
            'cpf' 
            );
    }
}
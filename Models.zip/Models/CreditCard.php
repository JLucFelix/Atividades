<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Person;

class CreditCard extends Model
{
    protected $table = 'credit_cards';
    protected $fillable = ['number', 'validity', 'CVV'];
    public function persons()
{

    return $this->hasmany(
        Person::class, 
        'cpf', 
        'cpf' 
        );
}
}
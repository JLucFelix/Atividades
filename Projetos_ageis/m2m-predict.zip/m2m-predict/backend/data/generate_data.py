import pandas as pd
import numpy as np
from faker import Faker
from datetime import date, timedelta
import random

fake = Faker()

def gen_series_for_sim(sim_id, days=180):
    end = date.today()
    start = end - timedelta(days=days-1)
    dates = pd.date_range(start=start, end=end, freq="D")
    base = np.linspace(100, 1500, len(dates))
    weekly = 200*np.sin(2*np.pi*dates.dayofweek/7)
    noise = np.random.normal(0, 120, len(dates))
    consumo = np.clip(base + weekly + noise + random.randint(-150,150), 10, None)
    return pd.DataFrame({"sim_id": sim_id, "data": dates, "consumo_mb": consumo.astype(int)})

def generate_mock_data(n_sims=30, days=180):
    sims = [fake.uuid4() for _ in range(n_sims)]
    dfs = [gen_series_for_sim(s, days) for s in sims]
    df = pd.concat(dfs, ignore_index=True)
    return df

if __name__ == "__main__":
    df = generate_mock_data()
    df.to_csv("data\\mock_consumo.csv", index=False)
    print("Gerado: data\\mock_consumo.csv")

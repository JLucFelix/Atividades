import pandas as pd
import numpy as np
from sklearn.preprocessing import OrdinalEncoder
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor
import pickle

RAW = "data\\mock_consumo.csv"
MODEL_PKL = "backend\\models\\xgb_model.pkl"
ENC_PKL = "backend\\models\\sim_encoder.pkl"

df = pd.read_csv(RAW, parse_dates=["data"])

# Features simples
df = df.sort_values(["sim_id","data"])
for lag in [1,2,3,7]:
    df[f"lag_{lag}"] = df.groupby("sim_id")["consumo_mb"].shift(lag)
df["ma_7"] = df.groupby("sim_id")["consumo_mb"].shift(1).rolling(7).mean()
df["dow"] = df["data"].dt.dayofweek
df = df.dropna()

X_num = df[["lag_1","lag_2","lag_3","lag_7","ma_7","dow"]].astype(float)
enc = OrdinalEncoder()
sim_enc = enc.fit_transform(df[["sim_id"]])
X = np.hstack([sim_enc, X_num.values])
y = df["consumo_mb"].values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

model = XGBRegressor(n_estimators=300, max_depth=6, learning_rate=0.05, subsample=0.9, colsample_bytree=0.9, random_state=42)
model.fit(X_train, y_train)

with open(MODEL_PKL, "wb") as f: pickle.dump(model, f)
with open(ENC_PKL, "wb") as f: pickle.dump(enc, f)

print("Modelo treinado e salvo em backend\\models")

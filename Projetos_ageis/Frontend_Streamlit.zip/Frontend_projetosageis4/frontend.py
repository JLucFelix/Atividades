import streamlit as st
import pandas as pd
import plotly.express as px
import requests
from faker import Faker
import random
from datetime import datetime

# --- Configurações da Página ---
st.set_page_config(
    page_title="Fulltime SIM Dashboard",
    page_icon="🔗",
    layout="wide"
)

# --- NOVA FUNÇÃO DE DADOS UNIFICADA ---
@st.cache_data(ttl=900) # Cache de 15 minutos
def create_unified_mock_data(num_employees=50):
    """
    Cria uma única fonte de dados com consumo mensal para cada funcionário.
    Isso substitui as duas funções de mock anteriores.
    """
    fake = Faker('pt_BR')
    departamentos = ["Vendas", "Técnico", "Marketing", "Administrativo", "Desenvolvimento"]

    # Gera a lista de meses desde Janeiro até o mês atual
    meses_pt = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
    current_month_index = datetime.now().month
    meses_atuais = meses_pt[:current_month_index]

    final_data = []

    for _ in range(num_employees):
        employee_name = fake.name()
        employee_job = fake.job()
        employee_dept = random.choice(departamentos)
        employee_email = fake.email()
        plano_gb = random.randint(10, 60)

        # Simula um perfil de consumo para o funcionário (alguns gastam mais, outros menos)
        base_consumo_ratio = random.uniform(0.7, 1.05)

        for mes in meses_atuais:
            # Adiciona uma variação mensal ao consumo base
            consumo_mensal = round(plano_gb * base_consumo_ratio * random.uniform(0.85, 1.15), 2)
            final_data.append({
                "Mês": mes,
                "Nome": employee_name,
                "Cargo": employee_job,
                "Departamento": employee_dept,
                "E-mail": employee_email,
                "Plano (GB)": plano_gb,
                "Consumo (GB)": consumo_mensal
            })

    df = pd.DataFrame(final_data)
    # Garante a ordem correta dos meses no gráfico
    df['Mês'] = pd.Categorical(df['Mês'], categories=meses_atuais, ordered=True)
    return df

# --- Barra Lateral de Navegação (Sidebar) ---
with st.sidebar:
    st.image("logo.png", use_container_width=True)
    st.title("Menu de Navegação")
    page = st.radio(
        "Escolha uma página:",
        # Adicionada a nova página "Sobre Nós" ao menu
        ("Página Inicial", "Sobre o Projeto", "Tecnologias", "Sobre Nós", "Dashboard"),
        label_visibility="collapsed"
    )

# --- Conteúdo Principal ---
if page == "Página Inicial":
    st.title("Bem-vindo ao Painel de Controle 🏠")
    st.markdown("Navegue pelo menu ao lado para explorar as seções do projeto.")

elif page == "Sobre o Projeto":
    st.title("Sobre o Projeto 📝")
    st.subheader("Solução complementar ao FullManager - Gestão de SIM Cards")
    st.markdown("Este projeto foi desenvolvido como uma solução para visualização e análise de dados de consumo de SIM cards, complementando a plataforma FullManager. O objetivo é oferecer dashboards interativos que permitam aos gestores uma visão clara e detalhada sobre o uso de dados por funcionários e departamentos, facilitando a tomada de decisões estratégicas e o controle de custos.")

elif page == "Tecnologias":
    st.title("Tecnologias Utilizadas 🚀")
    st.markdown("""
    - **Python:** Linguagem de programação principal para toda a lógica de backend e manipulação de dados.
    - **Streamlit:** Framework utilizado para a construção da interface web interativa e dos dashboards.
    - **Pandas:** Biblioteca para manipulação e análise de dados, essencial para o processamento das informações de consumo.
    - **Plotly Express:** Biblioteca para a criação de gráficos interativos e visualmente atraentes.
    - **Faker:** Usado para gerar dados fictícios (mock) para simular o ambiente de produção.
    """)

# --- NOVA SEÇÃO "SOBRE NÓS" ---
elif page == "Sobre Nós":
    st.title("Sobre Nós 👥")
    st.markdown("Conheça a equipe responsável pelo desenvolvimento deste projeto.")
    st.divider()

    # --- Lista de Participantes ---
    # !!! IMPORTANTE: Substitua os dados abaixo pelos dados reais da sua equipe !!!
    participantes = [
        {
            "nome": "Diego",
            "ra": "1989361",
            "funcao": "Back-end e modelo de predição.",
            "instagram_user": "diegoartero_" # Apenas o nome de usuário
        },
        {
            "nome": "Fernando",
            "ra": "1990340",
            "funcao": "Banco de dados.",
            "instagram_user": "fernandocaffer" # Apenas o nome de usuário
        },
        {
            "nome": "Guilherme",
            "ra": "1991991",
            "funcao": "Front-end.",
            "instagram_user": "guilherme.morrone" # Apenas o nome de usuário
        },
        {
            "nome": "Henrique",
            "ra": "1992437",
            "funcao": "Documentação do Projeto e Criação de Conteúdo.",
            "instagram_user": "rick.grram" # Apenas o nome de usuário
        },
        {
            "nome": "Jean",
            "ra": "2012388",
            "funcao": "Front-end.",
            "instagram_user": "jeanlucflx" # Apenas o nome de usuário
        },
        {
            "nome": "João",
            "ra": "1993739",
            "funcao": "Gerenciamento de Dados e Testes (QA).",
            "instagram_user": "Nissimura_" # Apenas o nome de usuário
        },
        {
            "nome": "Kaique",
            "ra": "1994836",
            "funcao": "Gerenciamento de Dados e Testes (QA).",
            "instagram_user": "kaikerenan11" # Apenas o nome de usuário
        },
        {
            "nome": "Leonardo",
            "ra": "1995657",
            "funcao": "Gerenciamento de Dados e Testes (QA).",
            "instagram_user": "toledx" # Apenas o nome de usuário
        },
        {
            "nome": "Maria Elisa",
            "ra": "2013350",
            "funcao": "Front-end.",
            "instagram_user": "mary_elisa7" # Apenas o nome de usuário
        }
    ]

    # Cria duas colunas para um layout mais organizado
    col1, col2 = st.columns(2)

    # Itera sobre a lista de participantes e os distribui nas colunas
    for i, participante in enumerate(participantes):
        # Alterna entre a coluna 1 e a coluna 2
        container = col1 if i % 2 == 0 else col2

        with container:
            st.subheader(participante["nome"])
            st.write(f"**RA:** {participante['ra']}")
            st.write(f"**Contribuição:** {participante['funcao']}")

            # Cria o link do Instagram que abre em uma nova aba
            insta_link = f'https://www.instagram.com/{participante["instagram_user"]}'
            st.markdown(f'<a href="{insta_link}" target="_blank" style="color: #E60000; text-decoration: none;">🔗 Perfil do Instagram</a>', unsafe_allow_html=True)
            st.write("---") # Adiciona um separador visual

elif page == "Dashboard":
    st.title("🔗 Dashboard de Consumo Unificado")
    st.markdown("Use os filtros abaixo para analisar o consumo de dados da empresa, departamentos e funcionários.")

    # Carrega os dados unificados
    df = create_unified_mock_data()

    # --- Filtros Dinâmicos ---
    st.subheader("Filtros Interativos")
    col1, col2 = st.columns(2)
    with col1:
        all_departments = df['Departamento'].unique()
        selected_depts = st.multiselect("Filtrar por Departamento:", options=all_departments, default=all_departments)

    with col2:
        # A lista de funcionários disponíveis muda com base nos departamentos selecionados
        available_employees = df[df['Departamento'].isin(selected_depts)]['Nome'].unique()
        selected_employees = st.multiselect("Filtrar por Funcionário:", options=available_employees, default=available_employees)

    # Aplica os filtros ao DataFrame
    df_filtered = df[(df['Departamento'].isin(selected_depts)) & (df['Nome'].isin(selected_employees))]

    st.divider()

    # --- KPIs Dinâmicos ---
    total_consumo = df_filtered['Consumo (GB)'].sum()
    # Pega o plano mensal de cada funcionário e soma (evita somar o mesmo plano várias vezes)
    total_plano = df_filtered.drop_duplicates(subset=['Nome'])['Plano (GB)'].sum()
    utilizacao = (total_consumo / (total_plano * len(df['Mês'].unique()))) * 100 if total_plano > 0 else 0

    kpi1, kpi2, kpi3 = st.columns(3)
    kpi1.metric("Consumo Total no Período", f"{total_consumo:.2f} GB")
    kpi2.metric("Soma dos Planos Mensais", f"{total_plano:.2f} GB")
    kpi3.metric("Utilização Média", f"{utilizacao:.2f}%")

    st.divider()

    # --- Gráficos Principais ---
    st.subheader("Análise de Consumo")

    # Gráfico de linha do consumo mensal total (baseado nos filtros)
    df_monthly_total = df_filtered.groupby('Mês')['Consumo (GB)'].sum().reset_index()
    fig_line = px.line(df_monthly_total, x='Mês', y='Consumo (GB)', markers=True,
                       title="Evolução do Consumo Mensal Total")
    fig_line.update_traces(line_color='#E60000')
    st.plotly_chart(fig_line, use_container_width=True)

    gcol1, gcol2 = st.columns(2)
    with gcol1:
        # Gráfico de barras do consumo total por departamento
        df_dept_breakdown = df_filtered.groupby('Departamento')['Consumo (GB)'].sum().sort_values(ascending=False).reset_index()
        fig_bar_dept = px.bar(df_dept_breakdown, x='Departamento', y='Consumo (GB)', color='Departamento',
                              title="Consumo Total por Departamento")
        st.plotly_chart(fig_bar_dept, use_container_width=True)

    with gcol2:
        # Gráfico de barras do consumo total por funcionário
        df_employee_breakdown = df_filtered.groupby('Nome')['Consumo (GB)'].sum().sort_values(ascending=False).reset_index().head(15)
        fig_bar_emp = px.bar(df_employee_breakdown, x='Nome', y='Consumo (GB)', color='Nome',
                             title="Top 15 Funcionários por Consumo Total")
        st.plotly_chart(fig_bar_emp, use_container_width=True)

    # --- Tabela de Dados Detalhados ---
    with st.expander("Ver tabela de dados detalhados (filtrados)"):
        st.dataframe(df_filtered, use_container_width=True)
from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
from datetime import timedelta
import os
app = Flask(__name__)
CORS(app)

HIST_CSV = "data/mock_consumo.csv"

# Carrega dados históricos
hist = pd.read_csv(HIST_CSV, parse_dates=["data"])

@app.get("/")
def home():
    return jsonify({"message":"API M2M Predict ativa"})

@app.post("/predict")
def predict():
    payload = request.get_json(force=True)
    sim_id = payload.get("sim_id")
    horizon = int(payload.get("horizon_days", 7))
    
    if not sim_id:
        return jsonify({"error":"sim_id obrigatório"}), 400

    # Filtra dados do SIM ID
    df_sim = hist[hist["sim_id"] == sim_id].sort_values("data")
    if df_sim.empty:
        return jsonify({"error":"sim_id não encontrado"}), 404

    # Pega os últimos 7 dias como base
    last = df_sim.iloc[-7:]
    lags = last["consumo_mb"].values[-7:]
    preds = []

    for i in range(horizon):
        # Simula previsão: último valor + ruído aleatório
        y_hat = float(lags[-1] + np.random.randint(-50, 50))
        y_hat = max(0, y_hat)
        next_day = last["data"].iloc[-1] + timedelta(days=i+1)
        preds.append({
            "data": next_day.strftime("%Y-%m-%d"),
            "consumo_mb_previsto": round(y_hat, 2)
        })
        # Atualiza lags
        lags = np.append(lags[1:], y_hat)

    return jsonify({"sim_id": sim_id, "horizon_days": horizon, "previsoes": preds})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
    

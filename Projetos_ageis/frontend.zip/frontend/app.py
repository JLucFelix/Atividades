import streamlit as st
import requests
import pandas as pd
import matplotlib.pyplot as plt

st.title("M2M Predict – Previsão de Consumo")

backend_url = "http://127.0.0.1:5000"

sim_id = st.text_input("SIM ID")
semestres = st.slider("Horizonte (semestres)", 1, 4, 1)
horizon = semestres * 180

if st.button("Prever") and sim_id:
    r = requests.post(f"{backend_url}/predict", json={"sim_id": sim_id, "horizon_days": horizon})
    
    if r.ok:
        data = r.json()["previsoes"]
        df = pd.DataFrame(data)

        # Converter data para datetime
        df["data"] = pd.to_datetime(df["data"])

        # Criar coluna de semana (início da semana)
        df["semana"] = df["data"].dt.to_period("W").apply(lambda r: r.start_time)

        # Agrupar por semana (soma dos consumos previstos)
        df_semana = df.groupby("semana")["consumo_mb_previsto"].sum().reset_index()

        # Mostrar tabela semanal
        st.subheader("Tabela de consumo previsto (semanal)")
        st.dataframe(df_semana)

        # Gráfico semanal
        plt.figure(figsize=(8, 4))
        plt.plot(df_semana["semana"], df_semana["consumo_mb_previsto"], marker="o")
        plt.xlabel("Semana")
        plt.ylabel("Consumo Previsto (MB)")
        plt.title("Previsão de Consumo por Semana")
        plt.xticks(rotation=45)
        st.pyplot(plt.gcf())
    
    else:
        st.error(r.text)

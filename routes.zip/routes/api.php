<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Models\Product;
use App\Models\Category;
use App\Models\Firm;

Route::post('/products' , function (Request $request) {
    $product = new Product();
    $product->name = $request->input('name');
    $product->price = $request->input('price');
    $product->description = $request->input('description' );
    $product->save();
    return response()->json($product);
});

Route::post('/categories' , function (Request $request) {
    $category = new Category();
    $category->name = $request->input('name');
    $category->description = $request->input('description' );
    $category->save();
    return response()->json($category);
});

Route::get('/categories' , function () {
    $category = Category::all();
    return response()->json($category);
});

Route::get('/products/{id}' , function ($id) {
    $product = Product::find($id);
    return response()->json($product);
});

Route::get('/products' , function () {
    $product = Product::all();
    return response()->json($product);
});

Route::get('/categories/{id}' , function ($id) {
    $category = Category::find($id);
    return response()->json($category);
});

Route::patch('/products/{id}', function (Request $request, $id) {
    $product = Product::find($id);
    if($request->input('name') !== null){
    $product->name = $request->input('name');
    }
    if($request->input('price') !== null){
    $product->price = $request->input('price');
    }
    if($request->input('description') !== null){
    $product->description = $request->input('description');
    }
    $product->save();
    return response()->json($product);
});

Route::patch('/categories/{id}', function (Request $request, $id) {
    $category = Category ::find($id);
    if($request->input('name') !== null){
    $category->name = $request->input('name');
    }
    if($request->input('description') !== null){
    $category->description = $request->input('description');
    }
    $category->save();
    return response()->json($category);
});

Route::delete('/products/{id}' , function ($id) {
    $product = Product::find($id);
    $product->delete();
    return response()->json($product);
});

Route::delete('/categories/{id}' , function ($id) {
    $category = Category::find($id);
    $category->products()->delete();
    $category->delete();
    
    return response()->json($category);
});

Route::post('/firms' , function (Request $request) {
    $firm = new Firm();

    $firm->name = $request->input('corporate_name');
    $firm->price = $request->input('trade_name');
    $firm->description = $request->input('CNPJ' );
    $firm->save();
    
    return response()->json($firm);
});

Route::get('/products/category/{id}', function ($id) {
    $product = Product::find($id);
    $category = $product->category;
    return response()->json($category);
});

Route::get('/products/category', function(){
    $products = Product::with('category')->get();
    return response()->json($products);
});

Route::get('/categories/products',function(){
    $category = Category::with('products')->get();
    return response()->json($category);
});

Route::get('categories/products/{id}', function ($id) {
    $category = Category::find($id);
    $products = $category->products;
    
    return response()->json($products);
});
